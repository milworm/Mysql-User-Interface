module ActiveSupport
  module Testing
    module Default #:nodoc:
      # Placeholder so test/unit ignores test cases without any tests.
      def default_test
      end
    end
  end
end
