module ActiveSupport
  module VERSION #:nodoc:
    MAJOR = 3
    MINOR = 0
    TINY  = 3
        
    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
