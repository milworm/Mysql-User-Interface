require 'active_support/core_ext/cgi/escape_skipping_slashes'
