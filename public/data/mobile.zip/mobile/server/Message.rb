class Message
  def initialize data={}
    @data = data
  end
  
  def add name, value
    @data[name] = value
  end
  
  def get name
    @data[name]
  end
  
  def get_raw_data
    @data
  end
end
