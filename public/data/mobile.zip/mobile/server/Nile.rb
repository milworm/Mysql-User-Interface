# Application server
# controls login procedure,
# collecting data for machine and
# saving them into database

require 'socket'
require 'singleton'
require 'thread'
require 'mysql'
require './Message'
require './PasswordService'

class Nile
  include Singleton
  
  protected
    @@port = 3005
    @@ip_address = '127.0.0.1'
    
    @@buff_size = 2000
    @connection = nil
    
    def log msg
      puts self.class.to_s + "::" + msg.to_s
    end
    
    def connect
      self.log "Trying to establish connection"

      begin
        @connection = TCPServer.open @@ip_address, @@port
        @db = Mysql.real_connect 'localhost', 'root', '23', 'mas'
      rescue => e
        self.log "Failed to establish connection"
        self.log e
        return false
      end
      
      self.log "Connection established"
      return true
    end
    
    def initialize
      @agents = {}
      @password_service = PasswordService.instance
    end
    
    def on_agent_connected agent
      self.log "Agent connected"
      Thread.start { self.on_agent_message_received agent }
    end
    
    def on_agent_message_received agent
      while true
        str = agent.recv(@@buff_size)
        break if str.length == 0 # connection close
        self.proccess_agent_message agent, str
      end
    end
    
    def proccess_agent_message agent, str
      message = self.parse_message str
      
      if message.get(:name) == 'login'
        self.login_agent agent, message
      elsif message.get(:name) == 'relogin'
	self.relogin_agent agent, message
      else
        self.update_statistics message
      end
    end
    
    def relogin_agent agent, message
      agent_config = @agents[message.get(:agent_id)]
      old_ip, new_ip, agent_id = agent_config[:ip], message.get(:agent_ip),  message.get(:agent_id)
      self.log "agent #{agent_id} has moved from #{old_ip} to #{new_ip}"
      # update agent info
      agent_config[:ip_address] = new_ip
      agent_config[:closed] = false
      agent_config[:connection] = agent
      agent_config[:count] = 0
      self.log "agent #{agent_id} has been successfully reconected"
      msg = self.create_message status: 0, name: message.get(:name)
      self.log "agent #{agent_id} login"
      agent.write msg
    end

    def parse_message str
      Marshal::load str
    end
    
    def login_agent agent, message
      ip = message.get :agent_ip
      agent_id = message.get :agent_id
      
      if @agents[agent_id].nil?
        @agents[agent_id] = {
          ip_address: ip,
          count: 0,
          closed: false,
          connection: agent
        }
      end
      
      msg = self.create_message status: 0, name: message.get(:name)
      agent.write msg
      self.log "agent #{agent_id} login"
    end

    def create_message hash
      msg = Message.new hash
      Marshal::dump msg
    end
    
    def update_statistics message
      agent_id = message.get :agent_id
      agent = @agents[agent_id]
      
      if agent[:closed] == true # skip
        return
      end

      params = message.get :params
      agent_ip = message.get :agent_ip

      #params.each {|k,v| params[k] = @db.quote v.to_s}
      sql = "INSERT INTO `statistics` (`agent_ip`, `cpu_load`, `memory_used`)
	           VALUES ('#{agent_ip}', '#{params[:cpu]}', '#{params[:ram]}')"
      self.log "statistics updated from #{agent_ip}" 
      @db.query sql
      @agents[agent_id][:count] += 1

      if @agents[agent_id][:count] % 10 == 0
        self.move_agent agent_id
      end
    rescue => e
      p e
    end

    def move_agent agent_id
      print "agent #{agent_id} is moving"
      agent = @agents[agent_id]
      access = @password_service.next agent[:ip_address]
      msg = self.create_message name: 'move', status: 0, params: access
      agent[:connection].write msg
      sleep(5) #default timeout that server should wait to receive last message
      agent[:closed] = true
      # from agent
    end
  
  public
    def run
      return unless self.connect

      loop do
        Thread.start @connection.accept do |agent|
          self.on_agent_connected agent
        end
      end
    rescue SystemExit, Interrupt => e
      self.log "Connection closed"
    end
end


if self.inspect == 'main'
  Nile.instance.run
end
