# MessageBus
require 'xmlrpc/server'

class MesageBus < XMLRPC::Server
  @@host = '127.0.0.1'
  @@port = 3002
  
  protected
    def log msg
      puts msg.to_s
    end
    
  public
    def initialize
      @server_list = {}
      super @@port, @@host
    end
  
    def init_handlers
      self.add_handler "send" do |message|
	self.send_message message
      end
    end
    
    def send_message message
      @server_list
    end
end

if self.name == 'main'
  
end
