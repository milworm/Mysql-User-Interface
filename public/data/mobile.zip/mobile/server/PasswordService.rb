require 'singleton'

class PasswordService
	include Singleton

	protected
		def initialize
			@access = [{
				ip_address: "127.0.0.1",
				user_name: "root",
				password: "23"
			}]
		end

	public
		def next ip_address
			@access.at @access.shuffle.find_index {|i| i[:ip_address] != ip_address}
		end
end