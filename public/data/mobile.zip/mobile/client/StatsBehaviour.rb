class StatsBehaviour
  def behave
    sleep(1)
    cpu_usage = `ps aux|awk 'NR > 0 { s +=$3 }; END {print s}'`
    free = `free -m | cut -d" " -f11`.gsub(/\n/,'').to_f
    used = `free -m | cut -d" " -f18`.gsub(/\n/,'').to_f
    ram_usage = ((used / free) * 100).round / 100.0
    
    return {
      ram: ram_usage.to_s.chop,
      cpu: cpu_usage.to_s.chop
    }
  end
end
