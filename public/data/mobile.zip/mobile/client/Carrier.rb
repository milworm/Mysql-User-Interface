require 'net/scp'

class Carrier
  def initialize host, user, pass
    @remove_agent_path = '/tmp'
    @host, @pass, @user = host, pass, user
    self.ssh_connect 
    self.scp_connect
  end
  
  def ssh_connect
    @ssh_connection = Net::SSH.start( @host, @user, :password => @pass )
  end
  
  def scp_connect
    @scp_connection = Net::SCP.new @ssh_connection
  end
  

  def upload
    local_file_path = File.expand_path(File.dirname(__FILE__))
    @scp_connection.upload!(local_file_path, @remove_agent_path, recursive: true)
  end
  
  def run_agent
    p "starting a shadow"
    @ssh_connection.exec! "source /etc/profile;nohup ruby #{@remove_agent_path}/client/MobileAgent.rb silent > /tmp/agent.log #> /dev/null"
    p "agent started on #{@host}"
  end
end
