#!/usr/local/rvm/rubies/ruby-1.9.2-p290/bin/ruby
class Object
  def __DIR__
    File.realdirpath(File.dirname(__FILE__))
  end
end

require __DIR__ + '/Message'
require __DIR__ + '/Carrier'
require __DIR__ + '/StatsBehaviour'
require 'socket'
require 'json'
require 'yaml'
require 'digest/md5'

class MobileAgent
  @@host = '127.0.0.1'
  @@port = 3005
  @@buff_size = 2000
  
  protected
    def log msg
      puts msg.to_s
    end
    
    def connect
      @socket_connection = TCPSocket.open @@host, @@port
    rescue => e
      self.log e
      return false
    end
    
    def start_income_thread
      Thread.start do
        while true
          message = @socket_connection.recv @@buff_size
          return if message.length == 0
          self.process_message message
        end
	
        self.log "Connection was closed"
      end
      #json = @socket_connection.recv(@@buff_size)
      #break if json.length == 0 #connection closed
    end
    
    def process_message message
      obj = Marshal::load message
      
      if obj.get(:name) == 'login'
        if obj.get(:status) == 0
          @login = true
          self.log "login passed"
        else
          self.log "Login Failed #{obj[:msg]}"
          self.disconnect
        end
      elsif obj.get(:name) == 'move'
        self.move obj
      elsif obj.get(:name) == 'relogin'
	@login = true
        self.log "reconnected"
      end
    end
    
    def get_state
	{agent_id: @agent_id}
    end
    
    def before_move
      state = self.get_state
      File.open './config.yml', 'w' do |file|
	file.write YAML::dump state
      end
    end

    def move message
      @freze = true
      self.log 'waiting the timeout'
      sleep(5) #default timeout
      self.log 'moving'
      self.before_move
      params = message.get :params
      
      @carrier = Carrier.new params[:ip_address], params[:user_name], params[:password]
      @carrier.upload
      @carrier.run_agent
      self.disconnect
      exit
    rescue => e
      p e
    end

    def disconnect
      @socket_connection.close
    end
    
    def send_message message
      str = Marshal::dump message
      self.log "sending message"
      @socket_connection.write str
      self.log "message sent"
    end
    
    def login
      message = self.create_message name: "login"
      self.send_message message
    end
    
    def relogin
      message = self.create_message name: "relogin"
      self.send_message message
    end

    def get_ip_address
      Socket.ip_address_list.detect{|intf| intf.ipv4_private?}.ip_address
    rescue => e
      'localhost'
    end

    def create_message hash
      p hash
      msg = Message.new hash
      msg.add :agent_id, @agent_id
      msg.add :agent_ip, self.get_ip_address
      return msg
    end
    
  public
    def initialize
      @behaviour = StatsBehaviour.new
      @agent_id = Digest::MD5.hexdigest Time.now.to_s
      @connection = nil
      @freze = false
      @login = false
      #self.create_shapshot
    end
    
    def create_shapshot
      local_file_path = File.expand_path(File.dirname(__FILE__))
      `tar -czf mobile.tar.gz ./  2>&1`
    end
    
    def run
      return unless self.connect
      self.start_income_thread
      self.login
      
      while true
        next unless @login
        next if @freze
        result = @behaviour.behave
        message = self.create_message params: result, name: 'statistics'
        self.send_message message
      end
    end
    
    def read_config
      config = YAML::load(File.open(__DIR__ + "/config.yml"))
      @agent_id = config[:agent_id]
    end
    
    def run_silent
      self.read_config
      return unless self.connect
      self.start_income_thread
      self.relogin
      
      while true
	next unless @login
        next if @freze
	result = @behaviour.behave
        message = self.create_message params: result, name: 'statistics'
	self.send_message message
      end
    end
end

if self.inspect == 'main'
  ARGV.length == 0 ? MobileAgent.new.run : MobileAgent.new.run_silent
end
